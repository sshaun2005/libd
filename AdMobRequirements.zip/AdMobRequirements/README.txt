If you have any errors kindly reach me via my Telegram channel https://t.me/thorenkoder.

First release of All AdMob Ad Tutorial in Sketchware is by Thoren Koder Channel, intended to
help Sketchware developers with the latest integration sonce even Sk-Modders are finding it hard to keep up
this is release 8 of this project

AllAdMob Ads release 8.0 ✴️✴️✴️✴️
      
# CHANGELOG

- Updated Ui.
- Updated Blocks & Components.
- Interstitial Ad now has components.
- Fixed bugs in the blocks.
- SetUp Example of Ads working in fragment.
- All AdMob Ads are properly featured.
- Upgraded App Open Ads...now using An Application class to run everything.

#WHAT TO EXPECT IN THE NEXT RELEASE

After i give and explanation on AdMob Native Ads i would be done with AdMob Tutorials,
aside integrations i would also love to touch topics of do's and don't when using AdMob and how to implement App Adstxt

- Library Downloader Project.
I have put in some effort to reedit Sketchware Library Downloader to work Recursively, i should be done in the next update
that means you would be able to download ~ 85% of libraries in distribution.

- Updated Libraries
Once i have made the library downloader project i would no longer share the updated Libraries only it's
dependency...all you will do is download it using the tool.

#DISCAIMER

- Don't take credit for work that isn't yours.
I have taken 7 months to reach perfection (this long because i am really busy and probably lazy),
so kindly give credits whenever you use, share, and make tutorials with my blocks & components e.t.c.

- I love sharing
If you are a Sketchware YouTuber and you are reading this it would be best if you share this project so that
others can use something better

- Just incase i don't release the library downloader Project I would update the libraries, currently which are 21.0.1

-------------------------SUBSCRIBE---MY---CHANNELS---FOR---MORE---INFO---------------------

YouTube Channel:
https://youtube.com/channel/UCYEuCLUawzTgFSj6tMluEXw

Telegram Group:
https://t.me/thorenkoder_com

Telegram Channel:
https://t.me/thorenkoder

Integrating Admob Ads(contains firebase fix):
https://youtu.be/lO2A27niT5g

Banner Ad:
https://youtu.be/zkELfUgGKig

Interstial Ad:
https://youtu.be/5ch4Yf0a8_Q

App-Open Ad:
https://youtu.be/ayH0DK4NDrM

Rewarded Ad:
https://youtu.be/h4v30Nw73B8